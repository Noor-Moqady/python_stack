from django.apps import AppConfig


class AppBooksAuthorsShellConfig(AppConfig):
    name = 'app_books_authors_shell'
