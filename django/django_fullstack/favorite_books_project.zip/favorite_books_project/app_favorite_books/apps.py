from django.apps import AppConfig


class AppFavoriteBooksConfig(AppConfig):
    name = 'app_favorite_books'
