from django.apps import AppConfig


class AppTheWallConfig(AppConfig):
    name = 'app_the_wall'
